# Assignment-
Python code
